# PickAFlick Server Patch (Drop-in)

This server gives you:
- A **clean backend** for your "pick 1 of 2" taste test
- **Only** uses movies from these IMDb lists (small, fast to boot):
  - https://www.imdb.com/list/ls094921320/
  - https://www.imdb.com/list/ls003501243/
- Hydration via **TMDb** for posters and trailers (uses `FIND` by IMDb ID)
- **Custom features only** (no reliance on genres/year): `vibe_tags`, `pace`, `decade`, `keywords`, `people`
- Pairwise learning (**content weights + Elo**), **active** pair selection, **MMR** diversified recommendations
- Minimal, fast endpoints: `/api/pair`, `/api/vote`, `/api/recommendations`, `/api/feedback`, `/api/health`

## Quick Start (Replit)

1) Drop the `server/` folder into your project root (do **not** touch your existing client UI).
2) In Replit **Secrets** add:
   - `TMDB_API_READ` = your **TMDb Read Access Token (v4)** (starts with `eyJ...`)
3) Shell:
   ```bash
   cd server
   npm i
   npm run dev
   ```
   The server runs on **http://localhost:3001** and starts building the small catalogue automatically.

> The UI can keep using whatever it currently uses. If it calls `/api/...`, you're done. If it uses a different base, point your API base to `http://localhost:3001/api`.

## Endpoints

### `GET /api/pair`
Returns two movies to compare:
```json
{
  "a": { "imdbId": "tt1234567", "title": "Movie A", "posterUrl": "...", "trailerKey": "YouTubeKey" },
  "b": { "imdbId": "tt7654321", "title": "Movie B", "posterUrl": "...", "trailerKey": "YouTubeKey" }
}
```

### `POST /api/vote`
Body:
```json
{ "a": "tt123...", "b": "tt456...", "winner": "A" }
```
Updates content weights + Elo.

### `GET /api/recommendations?limit=12`
Returns diversified items with posters and (when available) trailers:
```json
{ "items": [ { "imdbId":"tt...", "title":"...", "posterUrl":"...", "trailerKey":"..." }, ... ] }
```

### `POST /api/feedback`
Body:
```json
{ "movieId":"tt...", "action":"seen" | "block" | "like" | "dislike" }
```

### `GET /api/health`
Basic counts:
```json
{ "ok": true, "counts": { "catalogue": 75, "hydrated": 75 } }
```

## Notes

- Catalogue is cached in `server/cache/*.json` to speed up dev restarts.
- **Guardrails**: no repeat pairs, cooldown of recently shown titles.
- The recommendations endpoint **always responds** quickly; even with zero votes, you'll get a reasonable diversified list from the two lists provided.
- If you have a pre-existing client expecting different shapes, adapt the mapping in `GET /api/pair` and `GET /api/recommendations` (two tiny formatters) rather than touching your UI.
- To expand later, just add more IMDb list URLs in `src/constants.ts` and redeploy. The memory footprint stays small.

## Troubleshooting

- **Trailer reel stuck on loading:**
  - Hit `GET /api/health` — ensure `hydrated > 0`.
  - Ensure `TMDB_API_READ` secret is set. Without it, posters/trailers will be sparse (endpoint still works, but posters may be `null`).
  - Your UI might be expecting a different field name — adjust the formatter in `index.ts` to match exactly.
- **CORS issues:** The server enables `cors({ origin: true, credentials: true })`. If your UI is at a different origin, you're covered. If you proxy through Vite, point `/api` to `http://localhost:3001`.
- **Sessions:** The server auto-assigns a `sid` cookie for per-user learning. No UI changes needed.

Enjoy!