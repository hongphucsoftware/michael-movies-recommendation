import axios from "axios";
import * as cheerio from "cheerio";
import { MovieLite } from "./types.js";

export async function fetchImdbList(listUrl: string): Promise<MovieLite[]> {
  const res = await axios.get(listUrl, { headers: { "Accept-Language": "en-US,en;q=0.9", "User-Agent": "Mozilla/5.0" } });
  const $ = cheerio.load(res.data);
  const out: MovieLite[] = [];

  // IMDb list pages typically contain anchors to /title/ttXXXXXX/
  $("a[href*='/title/tt']").each((_, el) => {
    const href = $(el).attr("href") || "";
    const m = href.match(/\/title\/(tt\d{7,8})/);
    if (!m) return;
    const imdbId = m[1];
    // Try to get title text nearby
    const titleText = $(el).text().trim();
    if (!titleText) return;
    // Try to find year nearby
    let year: number | undefined = undefined;
    const parent = $(el).closest(".lister-item, .ipc-metadata-list-summary-item, .lister-item-content");
    const yearText = parent.find(".lister-item-year, .cli-title-metadata-item").first().text().trim();
    const ym = yearText && yearText.match(/(19\d{2}|20\d{2})/);
    if (ym) year = parseInt(ym[1],10);
    // Avoid duplicates
    if (!out.some(x=>x.imdbId===imdbId)){
      out.push({ imdbId, title: titleText, year });
    }
  });

  // De-duplicate by id, keep first
  const dedup = out.filter((m, i, arr) => arr.findIndex(z=>z.imdbId===m.imdbId)===i);
  return dedup;
}