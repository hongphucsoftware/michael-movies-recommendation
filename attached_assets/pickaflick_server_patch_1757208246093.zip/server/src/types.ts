export type MovieLite = {
  imdbId: string;
  title: string;
  year?: number;
};

export type MovieHydrated = MovieLite & {
  tmdbId?: number;
  posterPath?: string | null;
  backdropPath?: string | null;
  trailerKey?: string | null; // YouTube
  runtime?: number | null;
  keywords?: string[];
  people?: string[]; // cast/crew names
  decade?: string | null;
  pace?: 'slow'|'medium'|'fast'|null;
  vibe_tags?: string[];
  features?: number[]; // encoded features vector
};

export type UserState = {
  id: string;
  w: number[]; // content weights
  recentlyShown: string[]; // imdbIds
  pairsShown: Set<string>; // pair keys "a|b" sorted
  ratings: Map<string, { r: number; comps: number; wins: number; losses: number; }>; // per imdbId
  winners: Set<string>;
  blocked: Set<string>;
  seen: Set<string>;
};