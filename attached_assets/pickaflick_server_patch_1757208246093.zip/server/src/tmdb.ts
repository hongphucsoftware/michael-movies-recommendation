import axios from "axios";
import { MovieHydrated, MovieLite } from "./types.js";

const TMDB = "https://api.themoviedb.org/3";

const tmdb = axios.create({
  baseURL: TMDB,
  headers: { "Authorization": `Bearer ${process.env.TMDB_API_READ || ""}` }
});

export async function hydrateOne(base: MovieLite): Promise<MovieHydrated> {
  const result: MovieHydrated = { ...base, keywords: [], people: [], decade: null, pace: null, vibe_tags: [] };

  try{
    // Map IMDb ID -> TMDb ID
    const find = await tmdb.get(`/find/${base.imdbId}`, { params: { external_source: "imdb_id" }});
    const movie = (find.data.movie_results?.[0]) || null;
    if (!movie) return result;
    const tmdbId = movie.id;
    const details = await tmdb.get(`/movie/${tmdbId}`, { params: { append_to_response: "videos,keywords,credits" } });

    const d = details.data;
    result.tmdbId = tmdbId;
    result.posterPath = d.poster_path || null;
    result.backdropPath = d.backdrop_path || null;
    result.runtime = d.runtime ?? null;
    result.decade = (d.release_date && d.release_date.length >= 4) ? `${d.release_date.slice(0,3)}0s` : null;

    // Trailer: prefer official trailer on YouTube
    const vids = d.videos?.results || [];
    const trailer = vids.find((v:any)=> v.site==="YouTube" && /Trailer/i.test(v.type)) || vids.find((v:any)=> v.site==="YouTube");
    result.trailerKey = trailer ? trailer.key : null;

    // Keywords
    const kw = (d.keywords?.keywords || d.keywords || []).map((k:any)=> (k.name||"").toLowerCase()).filter(Boolean);
    result.keywords = Array.from(new Set(kw)).slice(0, 20);

    // People: top 5 cast + director(s)
    const cast = (d.credits?.cast || []).slice(0,5).map((c:any)=>c.name).filter(Boolean);
    const crew = (d.credits?.crew || []).filter((c:any)=>c.job==="Director").map((c:any)=>c.name);
    result.people = Array.from(new Set([...cast, ...crew]));

    // Pace heuristic from runtime
    if (typeof d.runtime === "number" && d.runtime > 0){
      result.pace = d.runtime <= 100 ? "fast" : d.runtime <= 130 ? "medium" : "slow";
    } else {
      result.pace = null;
    }

    // Vibe tags heuristic from keywords
    const vibes = new Set<string>();
    const addIf = (cond:boolean, tag:string)=>{ if (cond) vibes.add(tag); };
    const ks = result.keywords || [];
    const low = (s:string)=> ks.some(k=>k.includes(s));
    addIf(low("crime")||low("noir")||low("gritty")||low("revenge")||low("assassin"), "dark");
    addIf(low("feel good")||low("friendship")||low("heartwarming")||low("family"), "feel-good");
    addIf(low("quirky")||low("indie")||low("eccentric"), "quirky");
    addIf(low("violent")||low("gore")||low("brutal")||low("war"), "violent");
    addIf(low("romance")||low("love")||low("wedding"), "rom-com");
    addIf(low("dystopian")||low("moody")||low("brooding"), "moody");
    addIf(low("epic")||low("saga")||low("sweeping"), "epic");
    result.vibe_tags = Array.from(vibes);

    return result;
  }catch(e){
    return result;
  }
}