export function sigmoid(z: number){ return 1/(1+Math.exp(-z)); }
export function dot(a: number[], b: number[]){ let s=0; for(let i=0;i<a.length;i++) s += (a[i]||0)*(b[i]||0); return s; }
export function addInPlace(a:number[], b:number[]){ for(let i=0;i<a.length;i++) a[i]=(a[i]||0)+(b[i]||0); return a; }
export function sub(a:number[], b:number[]){ const out: number[] = []; const L = Math.max(a.length,b.length); for(let i=0;i<L;i++) out.push((a[i]||0)-(b[i]||0)); return out; }
export function l2(a:number[]){ return Math.sqrt(dot(a,a)); }
export function cosine(a:number[], b:number[]){
  const da = l2(a)||1e-9; const db = l2(b)||1e-9; return dot(a,b)/(da*db);
}
export function mmrSelect<T>(items: T[], k: number, sim: (a:T,b:T)=>number, score:(x:T)=>number){
  const chosen: T[] = [];
  const remaining = items.slice().sort((x,y)=>score(y)-score(x));
  while (chosen.length < k && remaining.length){
    let best: T | null = null;
    let bestVal = -Infinity;
    for (const cand of remaining){
      const rel = score(cand);
      let div = 0;
      if (chosen.length){
        div = Math.max(...chosen.map(c=>sim(c, cand)));
      }
      const val = 0.7*rel - 0.3*div;
      if (val > bestVal){ bestVal = val; best = cand; }
    }
    if (!best) break;
    chosen.push(best);
    const idx = remaining.indexOf(best);
    remaining.splice(idx,1);
  }
  return chosen;
}