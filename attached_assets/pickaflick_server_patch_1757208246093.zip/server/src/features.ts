import { MovieHydrated } from "./types.js";

const VIBE_VOCAB = ['dark','feel-good','quirky','violent','rom-com','moody','epic'] as const;
const PACE_VOCAB = ['slow','medium','fast'] as const;
const DECADE_VOCAB = ['1970s','1980s','1990s','2000s','2010s','2020s'] as const;

function multiHot(values: string[]|undefined, vocab: readonly string[]): number[]{
  const v = new Array(vocab.length).fill(0);
  (values||[]).forEach(tag=>{
    const i = vocab.indexOf(tag);
    if (i>=0) v[i]=1;
  });
  return v;
}

function oneHot(value: string|undefined|null, vocab: readonly string[]): number[]{
  const v = new Array(vocab.length).fill(0);
  if (!value) return v;
  const i = vocab.indexOf(value);
  if (i>=0) v[i]=1;
  return v;
}

// Simple hashing trick to fixed-dim vectors for keywords/people (no external ML dep needed)
function hashToVec(tokens: string[]|undefined, dim=64): number[] {
  const vec = new Array(dim).fill(0);
  (tokens||[]).forEach(t=>{
    let h=0;
    for (let i=0;i<t.length;i++) h = ((h<<5)-h) + t.charCodeAt(i);
    const idx = Math.abs(h)%dim;
    vec[idx] += 1;
  });
  // L2 normalize
  const norm = Math.sqrt(vec.reduce((s,x)=>s+x*x,0)) || 1;
  return vec.map(x=>x/norm);
}

export function buildFeatures(m: MovieHydrated): number[] {
  const parts: number[][] = [];
  parts.push(multiHot(m.vibe_tags, VIBE_VOCAB));
  parts.push(oneHot(m.pace, PACE_VOCAB));
  parts.push(oneHot(m.decade||undefined, DECADE_VOCAB));
  parts.push(hashToVec(m.keywords, 64));
  parts.push(hashToVec(m.people, 32));
  return parts.flat();
}